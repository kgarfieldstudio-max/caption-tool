# Architecture

## Modules

- `src/pages/App.jsx`: Main UI and local storage persistence.
- `src/pages/Docs.jsx`: Swagger UI for local docs.
- `src/routes/AppRouter.jsx`: App routes and `/docs` entry.
- `src/config.js`: Environment and configuration.

## Environment

Runtime settings are loaded from `import.meta.env` and exposed through `src/config.js`.
