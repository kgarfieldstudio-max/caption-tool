import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import App from '../src/pages/App.jsx';

const localStorageMock = (() => {
  let store = {};
  return {
    clear() {
      store = {};
    },
    getItem(key) {
      return store[key] || null;
    },
    setItem(key, value) {
      store[key] = String(value);
    },
    removeItem(key) {
      delete store[key];
    },
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
});

describe('Tags', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('creates a tag with category and color, then allows selecting it for a card', () => {
    render(<App />);

    fireEvent.click(screen.getByTestId('open-tag-manager-header'));
    fireEvent.change(screen.getByTestId('tag-name'), { target: { value: '常用' } });
    fireEvent.click(screen.getByTestId('tag-cat-乐器'));
    fireEvent.click(screen.getByTestId('color-systemRed'));
    fireEvent.click(screen.getByTestId('tag-save'));

    expect(screen.getByText('常用')).toBeInTheDocument();

    fireEvent.click(screen.getByTestId('tag-manager-close'));

    fireEvent.click(screen.getByTestId('open-card-create'));
    const tagChip = screen.getByRole('button', { name: '常用' });
    expect(tagChip.className).toContain('text-[11px]');
    fireEvent.click(tagChip);

    fireEvent.change(screen.getByPlaceholderText('在这里输入需要快速复制的提示词、段落或结构...'), {
      target: { value: '带标签的卡片' },
    });
    fireEvent.click(screen.getByRole('button', { name: '保存至卡片流' }));
    expect(screen.getByText('带标签的卡片')).toBeInTheDocument();
    expect(screen.getAllByText('常用').length).toBeGreaterThan(0);
  });

  it('filters tags by category and supports batch delete', () => {
    render(<App />);

    fireEvent.click(screen.getByTestId('open-tag-manager-header'));

    fireEvent.change(screen.getByTestId('tag-name'), { target: { value: 'A' } });
    fireEvent.click(screen.getByTestId('tag-cat-乐器'));
    fireEvent.click(screen.getByTestId('tag-save'));

    fireEvent.change(screen.getByTestId('tag-name'), { target: { value: 'B' } });
    fireEvent.click(screen.getByTestId('tag-cat-结构'));
    fireEvent.click(screen.getByTestId('tag-save'));

    fireEvent.click(screen.getByTestId('tag-filter-乐器'));
    expect(screen.getByText('A')).toBeInTheDocument();
    expect(screen.queryByText('B')).not.toBeInTheDocument();

    fireEvent.click(screen.getByTestId('tag-filter-结构'));
    expect(screen.getByText('B')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: 'B' }));
    fireEvent.click(screen.getByRole('button', { name: '批量删除' }));
    expect(screen.queryByText('B')).not.toBeInTheDocument();
  });

  it('edits a tag and color picker updates aria-pressed state', () => {
    render(<App />);

    fireEvent.click(screen.getByTestId('open-tag-manager-header'));

    fireEvent.change(screen.getByTestId('tag-name'), { target: { value: 'X' } });
    fireEvent.click(screen.getByTestId('tag-cat-乐器'));
    fireEvent.click(screen.getByTestId('tag-save'));

    const editBtn = screen.getAllByTestId(/tag-edit-/)[0];
    fireEvent.click(editBtn);

    fireEvent.change(screen.getByTestId('tag-name'), { target: { value: 'X2' } });
    fireEvent.click(screen.getByTestId('tag-cat-结构'));
    fireEvent.click(screen.getByTestId('color-systemGreen'));

    expect(screen.getByTestId('color-systemGreen')).toHaveAttribute('aria-pressed', 'true');

    fireEvent.click(screen.getByTestId('tag-save'));

    fireEvent.click(screen.getByTestId('tag-filter-乐器'));
    expect(screen.queryByText('X2')).not.toBeInTheDocument();

    fireEvent.click(screen.getByTestId('tag-filter-结构'));
    expect(screen.getByText('X2')).toBeInTheDocument();
  });
});
