import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import App from '../src/pages/App.jsx';

const localStorageMock = (() => {
  let store = {};
  return {
    clear() {
      store = {};
    },
    getItem(key) {
      return store[key] || null;
    },
    setItem(key, value) {
      store[key] = String(value);
    },
    removeItem(key) {
      delete store[key];
    },
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
});

describe('App', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('renders default cards and allows search', () => {
    render(<App />);
    expect(screen.getByText('词库')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('搜索提示词...')).toBeInTheDocument();
    expect(screen.getAllByText('乐器').length).toBeGreaterThan(0);

    fireEvent.change(screen.getByPlaceholderText('搜索提示词...'), {
      target: { value: 'Hans Zimmer' },
    });
    expect(screen.getByText(/Hans Zimmer/i)).toBeInTheDocument();
  });

  it('opens create sheet and blocks empty save', () => {
    render(<App />);
    fireEvent.click(screen.getByTestId('open-card-create'));
    const saveButton = screen.getByRole('button', { name: '保存至卡片流' });
    expect(saveButton).toBeDisabled();
  });

  it('creates a new card', () => {
    render(<App />);
    fireEvent.click(screen.getByTestId('open-card-create'));
    fireEvent.change(screen.getByPlaceholderText('在这里输入需要快速复制的提示词、段落或结构...'), {
      target: { value: '新的提示词' },
    });
    fireEvent.click(screen.getByRole('button', { name: '保存至卡片流' }));
    expect(screen.getByText('新的提示词')).toBeInTheDocument();
  });
});
