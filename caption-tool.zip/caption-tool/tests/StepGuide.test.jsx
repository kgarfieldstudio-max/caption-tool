import React, { useEffect, useState } from 'react';
import { fireEvent, render, screen, within } from '@testing-library/react';
import StepGuide from '../src/components/StepGuide.jsx';

const getShadowRoot = () => {
  const host = screen.getByTestId('step-shadow-host');
  expect(host.shadowRoot).toBeTruthy();
  return host.shadowRoot;
};

describe('StepGuide isolation', () => {
  it('renders only the active step and does not leak other step DOM into the document', () => {
    const steps = [
      {
        id: 's1',
        title: '步骤 1',
        cssText: '.s1 { color: rgb(1, 2, 3); }',
        render: () => <div className="s1">STEP_ONE_ONLY</div>,
      },
      {
        id: 's2',
        title: '步骤 2',
        cssText: '.s2 { color: rgb(4, 5, 6); }',
        render: () => <div className="s2">STEP_TWO_ONLY</div>,
      },
    ];

    render(<StepGuide steps={steps} initialStepId="s1" />);

    expect(screen.queryByText('STEP_ONE_ONLY')).toBeNull();
    expect(screen.queryByText('STEP_TWO_ONLY')).toBeNull();

    const root = getShadowRoot();
    expect(within(root).getByText('STEP_ONE_ONLY')).toBeInTheDocument();
    expect(within(root).queryByText('STEP_TWO_ONLY')).toBeNull();

    fireEvent.click(screen.getByRole('button', { name: '下一步' }));

    const root2 = getShadowRoot();
    expect(within(root2).getByText('STEP_TWO_ONLY')).toBeInTheDocument();
    expect(within(root2).queryByText('STEP_ONE_ONLY')).toBeNull();
  });

  it('cleans up scope event listeners when switching steps', () => {
    let calls = 0;

    const Step1 = (scope) => {
      useEffect(() => scope.onWindow('test-event', () => (calls += 1)), [scope]);
      return <div>ONE</div>;
    };

    const steps = [
      { id: 's1', title: '步骤 1', render: Step1 },
      { id: 's2', title: '步骤 2', render: () => <div>TWO</div> },
    ];

    render(<StepGuide steps={steps} initialStepId="s1" />);

    window.dispatchEvent(new Event('test-event'));
    expect(calls).toBe(1);

    fireEvent.click(screen.getByRole('button', { name: '下一步' }));

    window.dispatchEvent(new Event('test-event'));
    expect(calls).toBe(1);
  });

  it('resets step state on navigation by remounting isolated container', () => {
    const StepWithState = () => {
      const [value, setValue] = useState('');
      return (
        <div>
          <input aria-label="v" value={value} onChange={(e) => setValue(e.target.value)} />
          <div>{value ? `VAL:${value}` : 'EMPTY'}</div>
        </div>
      );
    };

    const steps = [
      { id: 's1', title: '步骤 1', render: () => <StepWithState /> },
      { id: 's2', title: '步骤 2', render: () => <div>OTHER</div> },
    ];

    render(<StepGuide steps={steps} initialStepId="s1" />);

    const root1 = getShadowRoot();
    fireEvent.change(within(root1).getByLabelText('v'), { target: { value: 'abc' } });
    expect(within(root1).getByText('VAL:abc')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: '下一步' }));
    fireEvent.click(screen.getByRole('button', { name: '上一步' }));

    const root2 = getShadowRoot();
    expect(within(root2).getByText('EMPTY')).toBeInTheDocument();
  });
});

