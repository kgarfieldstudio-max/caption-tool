# Caption Tool

一个用于管理提示词卡片的前端应用，支持分类、搜索、复制与移动端友好编辑。

## 免安装打开（推荐给“像网页版一样”使用）

直接双击打开 [standalone.html](file:///c:/Users/Esc1086/Documents/%E6%95%88%E7%8E%87%E5%B7%A5%E5%85%B7/caption-tool/standalone.html) 即可使用（不需要安装 Node / npm）。

说明：

- 数据仍然保存在浏览器 LocalStorage（同一浏览器/同一台电脑可持续保存）
- 没有热重载、也没有 `/docs` 路由（因为不启动服务器）

## 本地启动三步曲

1. 克隆仓库
2. 一键安装依赖并创建环境
3. 启动开发服务器

```bash
git clone <your-repo-url>
cd caption-tool
./scripts/install.sh
./scripts/dev.sh
```

Windows:

```bat
git clone <your-repo-url>
cd caption-tool
.\scripts\install.bat
.\scripts\dev.bat
```

## 常见坑与排查命令

- Node 版本过低：`node -v`，建议使用 Node 18+。
- 依赖安装失败：`npm cache verify` 后重试安装。
- 端口被占用：修改 `.env` 中 `VITE_PORT`。

## API 文档

启动后访问 `http://127.0.0.1:5173/docs`。
