import React, { useEffect, useState } from 'react';
import { flattenApplePalette } from '../utils/appleHigPalette.js';

const palette = flattenApplePalette();

export default function TagChip({
  tag,
  selected = false,
  onClick,
  className = '',
  size = 'sm',
  showCategory = false,
}) {
  const swatch = palette[tag.colorToken] || palette.systemBlue;
  const padding = size === 'xs' ? 'px-2 py-1' : 'px-2.5 py-1';
  const textSize = size === 'xs' ? 'text-[11px]' : 'text-[12px]';
  const dotSize = size === 'xs' ? 'w-2 h-2' : 'w-2.5 h-2.5';
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    if (!window?.matchMedia) return;
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = () => setIsDark(Boolean(media.matches));
    handler();
    if (media.addEventListener) {
      media.addEventListener('change', handler);
      return () => media.removeEventListener('change', handler);
    }
    media.addListener(handler);
    return () => media.removeListener(handler);
  }, []);

  return (
    <button
      type="button"
      data-testid={`tag-chip-${tag.id}`}
      onClick={onClick}
      className={[
        'inline-flex items-center gap-1.5 rounded-full border transition-colors select-none',
        padding,
        textSize,
        'font-semibold leading-none',
        'bg-white/70 dark:bg-white/5',
        selected
          ? 'border-[#007AFF] text-[#007AFF] dark:text-[#0A84FF] dark:border-[#0A84FF]'
          : 'border-gray-200/70 text-gray-700 hover:bg-white dark:border-white/10 dark:text-gray-200 dark:hover:bg-white/10',
        className,
      ].join(' ')}
      aria-pressed={selected}
    >
      <span
        className={`${dotSize} rounded-full`}
        style={{
          backgroundColor: isDark ? swatch.dark : swatch.light,
        }}
      />
      <span className="truncate max-w-[10rem]">{tag.name}</span>
      {showCategory ? (
        <span className="ml-1 text-[10px] font-bold text-gray-400 dark:text-gray-500">
          {tag.category}
        </span>
      ) : null}
    </button>
  );
}
