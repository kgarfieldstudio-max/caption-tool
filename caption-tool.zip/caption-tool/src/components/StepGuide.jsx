import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

const baseCss = `
  :host { all: initial; }
  *, *::before, *::after { box-sizing: border-box; }
  .wrap { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #0b0b0c; }
  .head { display: flex; align-items: baseline; justify-content: space-between; gap: 10px; padding: 12px; }
  .title { font-size: 14px; font-weight: 900; letter-spacing: 0.02em; }
  .meta { font-size: 12px; font-weight: 700; color: rgba(11, 11, 12, 0.56); white-space: nowrap; }
  .nav { display: flex; gap: 8px; align-items: center; padding: 0 12px 12px; }
  .btn { height: 28px; border-radius: 4px; border: 0; padding: 0 10px; font-size: 12px; font-weight: 900; background: rgba(11, 11, 12, 0.06); color: #0b0b0c; cursor: pointer; }
  .btnPrimary { background: #0b0b0c; color: #ffffff; }
  .btn:disabled { opacity: 0.4; cursor: not-allowed; }
  .body { padding: 0 12px 12px; }
`;

function createIsolatedScope() {
  const cleanups = [];
  const addEventListener = (target, type, handler, options) => {
    if (!target?.addEventListener) return () => {};
    target.addEventListener(type, handler, options);
    const cleanup = () => {
      try {
        target.removeEventListener(type, handler, options);
      } catch {
        return;
      }
    };
    cleanups.push(cleanup);
    return cleanup;
  };

  const addCleanup = (fn) => {
    if (typeof fn !== 'function') return () => {};
    cleanups.push(fn);
    return fn;
  };

  const reset = () => {
    for (const fn of cleanups.splice(0, cleanups.length)) {
      try {
        fn();
      } catch {
        continue;
      }
    }
  };

  return {
    addCleanup,
    onWindow: (type, handler, options) => addEventListener(window, type, handler, options),
    onDocument: (type, handler, options) => addEventListener(document, type, handler, options),
    onTarget: addEventListener,
    reset,
  };
}

function ShadowStep({ cssText, children, hostTestId }) {
  const hostRef = useRef(null);
  const [shadowRoot, setShadowRoot] = useState(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const root = host.attachShadow({ mode: 'open' });
    setShadowRoot(root);
    return () => {
      setShadowRoot(null);
    };
  }, []);

  return (
    <div data-testid={hostTestId} ref={hostRef}>
      {shadowRoot
        ? createPortal(
            <>
              <style data-step-style="1">{cssText}</style>
              {children}
            </>,
            shadowRoot,
          )
        : null}
    </div>
  );
}

export default function StepGuide({ steps, initialStepId }) {
  const normalizedSteps = Array.isArray(steps) ? steps.filter(Boolean) : [];
  const initialIndex = useMemo(() => {
    if (!initialStepId) return 0;
    const idx = normalizedSteps.findIndex((s) => s.id === initialStepId);
    return idx >= 0 ? idx : 0;
  }, [initialStepId, normalizedSteps]);

  const [activeIndex, setActiveIndex] = useState(initialIndex);
  const [activationKey, setActivationKey] = useState(0);

  const activeStep = normalizedSteps[activeIndex];

  const scopeRef = useRef(null);
  if (!scopeRef.current) scopeRef.current = createIsolatedScope();

  useEffect(() => {
    scopeRef.current.reset();
    scopeRef.current = createIsolatedScope();
    setActivationKey((k) => k + 1);
    return () => {
      scopeRef.current?.reset?.();
    };
  }, [activeIndex]);

  if (!activeStep) return null;

  const stepCss = `${baseCss}\n${activeStep.cssText || ''}`;
  const canPrev = activeIndex > 0;
  const canNext = activeIndex < normalizedSteps.length - 1;

  return (
    <ShadowStep cssText={stepCss} hostTestId="step-shadow-host" key={`${activeStep.id}-${activationKey}`}>
      <div className="wrap">
        <div className="head">
          <div className="title">{activeStep.title}</div>
          <div className="meta">
            {activeIndex + 1}/{normalizedSteps.length}
          </div>
        </div>
        <div className="nav">
          <button
            type="button"
            className="btn"
            onClick={() => setActiveIndex((i) => Math.max(0, i - 1))}
            disabled={!canPrev}
            aria-label="上一步"
          >
            上一步
          </button>
          <button
            type="button"
            className="btn btnPrimary"
            onClick={() => setActiveIndex((i) => Math.min(normalizedSteps.length - 1, i + 1))}
            disabled={!canNext}
            aria-label="下一步"
          >
            下一步
          </button>
        </div>
        <div className="body">{typeof activeStep.render === 'function' ? activeStep.render(scopeRef.current) : null}</div>
      </div>
    </ShadowStep>
  );
}

