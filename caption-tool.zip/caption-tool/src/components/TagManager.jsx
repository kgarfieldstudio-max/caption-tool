import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Plus, X } from 'lucide-react';
import ColorPicker from './ColorPicker.jsx';
import TagChip from './TagChip.jsx';

const TAGS_STORAGE_KEY = 'promptmix_tags_v1';

const normalizeTag = (tag) => ({
  id: tag.id,
  name: String(tag.name || '').trim(),
  category: tag.category,
  colorToken: tag.colorToken || 'systemBlue',
});

const loadTags = () => {
  const raw = localStorage.getItem(TAGS_STORAGE_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.map(normalizeTag).filter((t) => t.id && t.name && t.category);
  } catch {
    return [];
  }
};

const persistTags = (tags) => {
  localStorage.setItem(TAGS_STORAGE_KEY, JSON.stringify(tags));
};

export default function TagManager({ isOpen, onClose, categories, onChange }) {
  const [tags, setTags] = useState([]);
  const [activeCategory, setActiveCategory] = useState('全部');
  const [selectedIds, setSelectedIds] = useState([]);

  const [editingId, setEditingId] = useState(null);
  const [draftName, setDraftName] = useState('');
  const [draftCategory, setDraftCategory] = useState(categories[0] || '');
  const [draftColorToken, setDraftColorToken] = useState('systemBlue');

  useEffect(() => {
    if (!isOpen) return;
    const loaded = loadTags();
    setTags(loaded);
    setSelectedIds([]);
    setActiveCategory('全部');
    setEditingId(null);
    setDraftName('');
    setDraftCategory(categories[0] || '');
    setDraftColorToken('systemBlue');
  }, [isOpen, categories]);

  useEffect(() => {
    if (!isOpen) return;
    persistTags(tags);
    onChange(tags);
  }, [tags, isOpen, onChange]);

  const filteredTags = useMemo(() => {
    const base = tags.slice().sort((a, b) => a.name.localeCompare(b.name, 'zh-Hans-CN'));
    if (activeCategory === '全部') return base;
    return base.filter((t) => t.category === activeCategory);
  }, [tags, activeCategory]);

  const grouped = useMemo(() => {
    const map = {};
    for (const cat of categories) map[cat] = [];
    for (const tag of filteredTags) {
      if (!map[tag.category]) map[tag.category] = [];
      map[tag.category].push(tag);
    }
    return map;
  }, [filteredTags, categories]);

  const startCreate = () => {
    setEditingId(null);
    setDraftName('');
    setDraftCategory(categories[0] || '');
    setDraftColorToken('systemBlue');
  };

  const startEdit = (tag) => {
    setEditingId(tag.id);
    setDraftName(tag.name);
    setDraftCategory(tag.category);
    setDraftColorToken(tag.colorToken || 'systemBlue');
  };

  const upsert = () => {
    const name = draftName.trim();
    if (!name) return;
    if (!draftCategory) return;
    const payload = {
      id: editingId || Date.now().toString(),
      name,
      category: draftCategory,
      colorToken: draftColorToken,
    };
    setTags((prev) => {
      const exists = prev.some((t) => t.id === payload.id);
      const next = exists ? prev.map((t) => (t.id === payload.id ? payload : t)) : [payload, ...prev];
      return next;
    });
    setEditingId(null);
    setDraftName('');
    setDraftCategory(categories[0] || '');
    setDraftColorToken('systemBlue');
  };

  const toggleSelect = (id) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const batchDelete = () => {
    if (selectedIds.length === 0) return;
    const setIds = new Set(selectedIds);
    setTags((prev) => prev.filter((t) => !setIds.has(t.id)));
    setSelectedIds([]);
  };

  const close = () => {
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen ? (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={close}
            className="fixed inset-0 bg-black/30 dark:bg-black/60 backdrop-blur-sm z-40"
          />
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 26, stiffness: 220 }}
            className="fixed bottom-0 left-0 right-0 max-w-3xl mx-auto bg-[#F9F9FB] dark:bg-[#1C1C1E] rounded-t-[32px] z-50 p-5 pb-safe-area flex flex-col shadow-[0_-10px_40px_rgba(0,0,0,0.1)] dark:border-t dark:border-white/10"
          >
            <div className="w-12 h-1.5 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-4" />

            <div className="flex items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <div className="text-[20px] font-extrabold tracking-tight">标签</div>
                <button
                  type="button"
                  onClick={startCreate}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full bg-white dark:bg-[#2C2C2E] border border-gray-200/70 dark:border-white/10 text-[#007AFF] font-bold text-[13px] active:scale-95 transition-transform"
                >
                  <Plus size={16} />
                  新建
                </button>
              </div>
              <button
                type="button"
                onClick={close}
                className="p-2 bg-gray-200/50 hover:bg-gray-200 dark:bg-white/10 dark:hover:bg-white/20 rounded-full text-gray-600 dark:text-gray-300 transition-colors"
                aria-label="关闭"
                data-testid="tag-manager-close"
              >
                <X size={20} strokeWidth={2.5} />
              </button>
            </div>

            <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-hide -mx-5 px-5 mb-2">
              {['全部', ...categories].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setActiveCategory(cat)}
                  className={[
                    'px-4 py-2 rounded-full text-[13px] font-extrabold whitespace-nowrap border',
                    activeCategory === cat
                      ? 'bg-[#007AFF] text-white border-[#007AFF]'
                      : 'bg-white/60 dark:bg-white/5 text-gray-600 dark:text-gray-300 border-gray-200/70 dark:border-white/10 hover:bg-white dark:hover:bg-white/10',
                  ].join(' ')}
                  data-testid={`tag-filter-${cat}`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[1.1fr_0.9fr] gap-3 overflow-auto">
              <div className="bg-white/70 dark:bg-white/5 border border-gray-200/70 dark:border-white/10 rounded-[18px] p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[12px] font-extrabold text-gray-400 dark:text-gray-500 tracking-wider uppercase">
                    按大类分组
                  </div>
                  <button
                    type="button"
                    onClick={batchDelete}
                    disabled={selectedIds.length === 0}
                    className={[
                      'px-2.5 py-1.5 rounded-full text-[12px] font-extrabold border transition-colors',
                      selectedIds.length === 0
                        ? 'border-gray-200/70 text-gray-400 dark:border-white/10 dark:text-gray-600 cursor-not-allowed'
                        : 'border-red-300/60 text-red-600 hover:bg-red-50 dark:border-red-500/20 dark:text-red-400 dark:hover:bg-red-500/10',
                    ].join(' ')}
                  >
                    批量删除
                  </button>
                </div>

                <div className="space-y-3">
                  {Object.entries(grouped).map(([cat, items]) => (
                    <div key={cat} className="border border-gray-200/60 dark:border-white/10 rounded-[16px] p-2">
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="text-[12px] font-extrabold text-gray-700 dark:text-gray-200 flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#007AFF]" />
                          {cat}
                        </div>
                        <div className="text-[11px] font-bold text-gray-400 dark:text-gray-500">
                          {items.length}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {items.map((tag) => (
                          <div key={tag.id} className="flex items-center gap-1">
                            <TagChip
                              tag={tag}
                              size="xs"
                              selected={selectedIds.includes(tag.id)}
                              onClick={() => toggleSelect(tag.id)}
                            />
                            <button
                              type="button"
                              onClick={() => startEdit(tag)}
                              className="px-2 py-1 rounded-full text-[11px] font-extrabold border border-gray-200/70 dark:border-white/10 text-gray-500 dark:text-gray-400 hover:bg-white dark:hover:bg-white/10"
                              data-testid={`tag-edit-${tag.id}`}
                            >
                              编辑
                            </button>
                          </div>
                        ))}
                        {items.length === 0 ? (
                          <div className="text-[12px] text-gray-400 dark:text-gray-500 py-1.5 px-1">
                            无标签
                          </div>
                        ) : null}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white/70 dark:bg-white/5 border border-gray-200/70 dark:border-white/10 rounded-[18px] p-3">
                <div className="text-[12px] font-extrabold text-gray-400 dark:text-gray-500 tracking-wider uppercase mb-2">
                  {editingId ? '编辑标签' : '新建标签'}
                </div>

                <div className="space-y-2">
                  <input
                    type="text"
                    value={draftName}
                    onChange={(e) => setDraftName(e.target.value)}
                    placeholder="标签名称（紧凑显示建议 ≤ 6 字）"
                    className="w-full bg-white dark:bg-black/40 border border-gray-200 dark:border-white/10 rounded-[12px] px-3 py-2 text-[14px] font-semibold text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#007AFF]/40 placeholder-gray-400"
                    data-testid="tag-name"
                  />

                  <div className="grid grid-cols-4 gap-1.5">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setDraftCategory(cat)}
                        className={[
                          'py-2 rounded-[12px] text-[12px] font-extrabold border',
                          draftCategory === cat
                            ? 'bg-[#007AFF] text-white border-[#007AFF]'
                            : 'bg-white/60 dark:bg-white/5 text-gray-600 dark:text-gray-300 border-gray-200/70 dark:border-white/10 hover:bg-white dark:hover:bg-white/10',
                        ].join(' ')}
                        data-testid={`tag-cat-${cat}`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  <ColorPicker value={draftColorToken} onChange={setDraftColorToken} />

                  <div className="flex items-center justify-between gap-2 mt-2">
                    <div className="flex flex-wrap gap-1.5">
                      {draftName.trim() ? (
                        <TagChip
                          tag={{
                            id: 'preview',
                            name: draftName.trim(),
                            category: draftCategory,
                            colorToken: draftColorToken,
                          }}
                          size="sm"
                          selected
                        />
                      ) : null}
                    </div>
                    <button
                      type="button"
                      onClick={upsert}
                      disabled={!draftName.trim() || !draftCategory}
                      className={[
                        'px-4 py-2 rounded-[14px] text-[14px] font-extrabold transition-all shadow-sm active:scale-95',
                        draftName.trim() && draftCategory
                          ? 'bg-[#007AFF] text-white hover:bg-blue-600'
                          : 'bg-gray-200 dark:bg-white/10 text-gray-400 dark:text-gray-600 cursor-not-allowed',
                      ].join(' ')}
                      data-testid="tag-save"
                    >
                      保存
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      ) : null}
    </AnimatePresence>
  );
}
