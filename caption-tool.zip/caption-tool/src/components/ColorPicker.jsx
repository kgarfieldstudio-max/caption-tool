import React, { useEffect, useState } from 'react';
import { APPLE_HIG_PALETTE } from '../utils/appleHigPalette.js';

const GROUP_LABELS = {
  primary: '主色',
  secondary: '辅助色',
  semantic: '语义色',
};

export default function ColorPicker({ value, onChange }) {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    if (!window?.matchMedia) return;
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = () => setIsDark(Boolean(media.matches));
    handler();
    if (media.addEventListener) {
      media.addEventListener('change', handler);
      return () => media.removeEventListener('change', handler);
    }
    media.addListener(handler);
    return () => media.removeListener(handler);
  }, []);

  return (
    <div className="space-y-3">
      {Object.entries(APPLE_HIG_PALETTE).map(([group, items]) => (
        <div key={group}>
          <div className="text-[12px] font-extrabold text-gray-400 dark:text-gray-500 tracking-wider uppercase mb-2">
            {GROUP_LABELS[group] || group}
          </div>
          <div className="grid grid-cols-9 sm:grid-cols-11 gap-1.5">
            {items.map((swatch) => {
              const selected = value === swatch.token;
              return (
                <button
                  key={swatch.token}
                  type="button"
                  data-testid={`color-${swatch.token}`}
                  aria-label={swatch.label}
                  aria-pressed={selected}
                  onClick={() => onChange(swatch.token)}
                  className={[
                    'w-7 h-7 rounded-full border transition-transform active:scale-95',
                    selected
                      ? 'border-[#007AFF] ring-2 ring-[#007AFF]/30'
                      : 'border-gray-200/70 dark:border-white/10 hover:scale-[1.03]',
                  ].join(' ')}
                  style={{
                    backgroundColor: isDark ? swatch.dark : swatch.light,
                  }}
                />
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
