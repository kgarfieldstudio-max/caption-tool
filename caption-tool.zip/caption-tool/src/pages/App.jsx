import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, MoreHorizontal, Plus, Search, Tag, X } from 'lucide-react';
import config from '../config.js';
import TagChip from '../components/TagChip.jsx';
import TagManager from '../components/TagManager.jsx';

const CATEGORIES = ['全部', '乐器', '结构', '人声', '节奏'];

const CATEGORY_STYLES = {
  乐器: { color: 'bg-purple-500', icon: '🎸' },
  结构: { color: 'bg-blue-500', icon: '🧱' },
  人声: { color: 'bg-pink-500', icon: '🎤' },
  节奏: { color: 'bg-orange-500', icon: '🥁' },
};

const DEFAULT_CARDS = [
  {
    id: '1',
    text: 'A cinematic Hans Zimmer style orchestral string section, playing a suspenseful rising ostinato.',
    category: '乐器',
    timestamp: Date.now(),
    tags: [],
  },
  {
    id: '2',
    text: 'Intro (4 bars) -> Verse 1 (8 bars) -> Pre-Chorus (4 bars) -> Chorus (8 bars) -> Drop.',
    category: '结构',
    timestamp: Date.now() - 1000,
    tags: [],
  },
  {
    id: '3',
    text: 'Ethereal female vocals, lots of reverb, singing wordless atmospheric melodies in minor key.',
    category: '人声',
    timestamp: Date.now() - 2000,
    tags: [],
  },
  {
    id: '4',
    text: 'Lo-Fi hip hop drum loop, dusty vinyl crackle, slightly swung hi-hats, deep sub kick.',
    category: '节奏',
    timestamp: Date.now() - 3000,
    tags: [],
  },
];

const copyToClipboard = async (text) => {
  try {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    const successful = document.execCommand('copy');
    textArea.remove();
    return successful;
  } catch (error) {
    console.error('Copy failed', error);
    return false;
  }
};

const Card = React.forwardRef(({ card, onEdit, tagsById }, ref) => {
  const [isCopied, setIsCopied] = useState(false);
  const copyTimeoutRef = useRef(null);

  const handleCopy = async () => {
    if (isCopied) return;
    const success = await copyToClipboard(card.text);
    if (success) {
      if (navigator.vibrate) navigator.vibrate(50);
      setIsCopied(true);
      if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
      copyTimeoutRef.current = setTimeout(() => {
        setIsCopied(false);
      }, 1000);
    }
  };

  const handleEditClick = (event) => {
    event.stopPropagation();
    onEdit(card);
  };

  const catStyle = CATEGORY_STYLES[card.category];

  return (
    <motion.div
      ref={ref}
      layout
      initial={{ opacity: 0, scale: 0.9, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
      whileTap={{ scale: 0.95 }}
      onClick={handleCopy}
      className="relative w-full bg-white dark:bg-[#1C1C1E] rounded-[20px] p-5 shadow-[0_4px_20px_rgba(0,0,0,0.03)] dark:shadow-none dark:border dark:border-white/10 cursor-pointer overflow-hidden group select-none flex flex-col"
    >
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center gap-2">
          <div className={`w-2.5 h-2.5 rounded-full ${catStyle?.color} shadow-sm`} />
          <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
            {card.category}
          </span>
        </div>
        <button
          onClick={handleEditClick}
          className="p-1.5 rounded-full bg-gray-50 hover:bg-gray-100 dark:bg-white/5 dark:hover:bg-white/10 transition-colors text-gray-400 dark:text-gray-400"
        >
          <MoreHorizontal size={18} />
        </button>
      </div>

      <div className="relative flex-grow flex items-start">
        <AnimatePresence mode="wait">
          {isCopied ? (
            <motion.div
              key="copied"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 flex flex-col items-center justify-center text-green-500 dark:text-green-400 bg-white/90 dark:bg-[#1C1C1E]/90 backdrop-blur-md rounded-lg z-10"
            >
              <CheckCircle2 size={32} className="mb-2" strokeWidth={2.5} />
              <span className="text-[15px] font-bold tracking-wide">已复制</span>
            </motion.div>
          ) : (
            <motion.div
              key="text"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="w-full text-[16px] leading-[1.6] text-gray-800 dark:text-gray-200 font-medium whitespace-pre-wrap break-words"
            >
              {card.text}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {Array.isArray(card.tags) && card.tags.length > 0 ? (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {card.tags
            .map((id) => tagsById[id])
            .filter(Boolean)
            .map((tag) => (
              <TagChip key={tag.id} tag={tag} size="xs" />
            ))}
        </div>
      ) : null}
    </motion.div>
  );
});

Card.displayName = 'Card';

const BottomSheet = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  initialData,
  tags,
  onOpenTagManager,
}) => {
  const [text, setText] = useState('');
  const [category, setCategory] = useState('乐器');
  const [selectedTagIds, setSelectedTagIds] = useState([]);

  useEffect(() => {
    if (isOpen) {
      if (initialData) {
        setText(initialData.text);
        setCategory(initialData.category);
        setSelectedTagIds(Array.isArray(initialData.tags) ? initialData.tags : []);
      } else {
        setText('');
        setCategory('乐器');
        setSelectedTagIds([]);
      }
    }
  }, [isOpen, initialData]);

  useEffect(() => {
    if (!isOpen) return;
    const allowed = new Set(tags.filter((t) => t.category === category).map((t) => t.id));
    setSelectedTagIds((prev) => prev.filter((id) => allowed.has(id)));
  }, [category, isOpen, tags]);

  const handleSave = () => {
    if (!text.trim()) return;
    onSave({
      id: initialData ? initialData.id : Date.now().toString(),
      text: text.trim(),
      category,
      timestamp: initialData ? initialData.timestamp : Date.now(),
      tags: selectedTagIds,
    });
    onClose();
  };

  const availableTags = tags.filter((t) => t.category === category);
  const toggleTag = (id) => {
    setSelectedTagIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/30 dark:bg-black/60 backdrop-blur-sm z-40"
          />
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 26, stiffness: 220 }}
            className="fixed bottom-0 left-0 right-0 max-w-2xl mx-auto bg-[#F9F9FB] dark:bg-[#1C1C1E] rounded-t-[32px] z-50 p-6 pb-safe-area flex flex-col shadow-[0_-10px_40px_rgba(0,0,0,0.1)] dark:border-t dark:border-white/10"
          >
            <div className="w-12 h-1.5 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-6" />

            <div className="flex justify-between items-center mb-6">
              <h2 className="text-[22px] font-bold text-gray-900 dark:text-white tracking-tight">
                {initialData ? '编辑卡片' : '新建提示词'}
              </h2>
              <button
                onClick={onClose}
                className="p-2 bg-gray-200/50 hover:bg-gray-200 dark:bg-white/10 dark:hover:bg-white/20 rounded-full text-gray-600 dark:text-gray-300 transition-colors"
              >
                <X size={20} strokeWidth={2.5} />
              </button>
            </div>

            <textarea
              autoFocus
              value={text}
              onChange={(event) => setText(event.target.value)}
              placeholder="在这里输入需要快速复制的提示词、段落或结构..."
              className="w-full h-40 p-4 bg-white dark:bg-black/40 border border-gray-200 dark:border-white/10 rounded-[16px] resize-none focus:outline-none focus:ring-2 focus:ring-[#007AFF] text-[17px] leading-[1.5] text-gray-900 dark:text-white mb-6 shadow-sm placeholder-gray-400"
            />

            <div className="mb-8">
              <label className="block text-[14px] font-semibold text-gray-500 dark:text-gray-400 mb-3 uppercase tracking-wider">
                分类模块
              </label>
              <div className="grid grid-cols-4 gap-2">
                {CATEGORIES.filter((cat) => cat !== '全部').map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`py-3 px-1 rounded-[14px] text-[15px] font-semibold transition-all duration-200 flex flex-col items-center gap-1 ${
                      category === cat
                        ? 'bg-white dark:bg-[#2C2C2E] text-[#007AFF] shadow-md border-2 border-[#007AFF]'
                        : 'bg-white/50 dark:bg-white/5 text-gray-600 dark:text-gray-400 border-2 border-transparent hover:bg-white dark:hover:bg-white/10'
                    }`}
                  >
                    <span>{CATEGORY_STYLES[cat].icon}</span>
                    <span>{cat}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-[14px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  标签（紧凑）
                </label>
                <button
                  type="button"
                  onClick={onOpenTagManager}
                  className="px-3 py-1.5 rounded-full text-[12px] font-extrabold border border-gray-200/70 dark:border-white/10 text-gray-500 dark:text-gray-400 hover:bg-white dark:hover:bg-white/10"
                  data-testid="open-tag-manager"
                >
                  管理
                </button>
              </div>

              {availableTags.length === 0 ? (
                <div className="text-[13px] text-gray-400 dark:text-gray-500">
                  当前大类暂无标签，可点“管理”创建
                </div>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {availableTags.map((tag) => (
                    <TagChip
                      key={tag.id}
                      tag={tag}
                      size="xs"
                      selected={selectedTagIds.includes(tag.id)}
                      onClick={() => toggleTag(tag.id)}
                    />
                  ))}
                </div>
              )}
            </div>

            <div className="flex gap-3 mt-auto">
              {initialData && (
                <button
                  onClick={() => {
                    onDelete(initialData.id);
                    onClose();
                  }}
                  className="flex-1 py-4 rounded-[16px] bg-red-100 text-red-600 dark:bg-red-500/10 dark:text-red-500 font-semibold text-[17px] active:scale-95 transition-all flex items-center justify-center"
                >
                  删除
                </button>
              )}
              <button
                onClick={handleSave}
                disabled={!text.trim()}
                className={`flex-[2] py-4 rounded-[16px] font-semibold text-[17px] active:scale-95 transition-all shadow-sm ${
                  text.trim()
                    ? 'bg-[#007AFF] text-white hover:bg-blue-600'
                    : 'bg-gray-200 dark:bg-white/10 text-gray-400 dark:text-gray-600 cursor-not-allowed'
                }`}
              >
                保存至卡片流
              </button>
            </div>

            <div className="h-4"></div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default function App() {
  const [cards, setCards] = useState([]);
  const [activeTab, setActiveTab] = useState('全部');
  const [searchQuery, setSearchQuery] = useState('');

  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editingCard, setEditingCard] = useState(null);
  const [tags, setTags] = useState([]);
  const [isTagManagerOpen, setIsTagManagerOpen] = useState(false);

  const categoriesForTags = CATEGORIES.filter((c) => c !== '全部');

  const tagsById = useMemo(() => {
    const map = {};
    for (const t of tags) map[t.id] = t;
    return map;
  }, [tags]);

  const normalizeCard = (card) => ({
    ...card,
    tags: Array.isArray(card.tags) ? card.tags : [],
  });

  const loadTags = () => {
    const raw = localStorage.getItem('promptmix_tags_v1');
    if (!raw) return [];
    try {
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed
        .map((t) => ({
          id: t.id,
          name: String(t.name || '').trim(),
          category: t.category,
          colorToken: t.colorToken || 'systemBlue',
        }))
        .filter((t) => t.id && t.name && t.category);
    } catch {
      return [];
    }
  };

  useEffect(() => {
    const saved = localStorage.getItem('promptmix_cards_v2');
    if (saved) {
      setCards(JSON.parse(saved).map(normalizeCard));
    } else {
      setCards(DEFAULT_CARDS.map(normalizeCard));
      localStorage.setItem('promptmix_cards_v2', JSON.stringify(DEFAULT_CARDS.map(normalizeCard)));
    }
    setTags(loadTags());
  }, []);

  useEffect(() => {
    if (cards.length > 0) {
      localStorage.setItem('promptmix_cards_v2', JSON.stringify(cards));
    } else if (cards.length === 0 && localStorage.getItem('promptmix_cards_v2')) {
      localStorage.setItem('promptmix_cards_v2', JSON.stringify([]));
    }
  }, [cards]);

  const filteredCards = cards
    .filter((card) => activeTab === '全部' || card.category === activeTab)
    .filter((card) => card.text.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => b.timestamp - a.timestamp);

  const handleSaveCard = (cardData) => {
    if (editingCard) {
      setCards(cards.map((card) => (card.id === cardData.id ? cardData : card)));
    } else {
      setCards([cardData, ...cards]);
    }
    if (activeTab !== '全部' && activeTab !== cardData.category) {
      setActiveTab('全部');
    }
  };

  const handleDeleteCard = (id) => {
    setCards(cards.filter((card) => card.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#F2F2F7] dark:bg-[#000000] font-sans antialiased text-gray-900 dark:text-gray-100 pb-24 selection:bg-[#007AFF]/30 transition-colors duration-300">
      <header className="sticky top-0 z-30 bg-[#F2F2F7]/85 dark:bg-[#000000]/85 backdrop-blur-xl border-b border-gray-200/50 dark:border-white/10 px-4 pt-6 pb-3 md:px-8 mx-auto max-w-3xl shadow-[0_1px_3px_rgba(0,0,0,0.02)]">
        <div className="flex justify-between items-center mb-5">
          <h1 className="text-[32px] font-extrabold tracking-tight">词库</h1>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsTagManagerOpen(true)}
              className="w-11 h-11 bg-white dark:bg-[#1C1C1E] text-gray-500 dark:text-gray-300 rounded-full shadow-sm flex items-center justify-center hover:bg-blue-50 dark:hover:bg-white/10 active:scale-90 transition-all border border-transparent dark:border-white/5"
              aria-label="标签"
              data-testid="open-tag-manager-header"
            >
              <Tag size={22} strokeWidth={2.5} />
            </button>
            <button
              type="button"
              onClick={() => {
                setEditingCard(null);
                setIsSheetOpen(true);
              }}
              className="w-11 h-11 bg-white dark:bg-[#1C1C1E] text-[#007AFF] rounded-full shadow-sm flex items-center justify-center hover:bg-blue-50 dark:hover:bg-white/10 active:scale-90 transition-all border border-transparent dark:border-white/5"
              aria-label="新建"
              data-testid="open-card-create"
            >
              <Plus size={26} strokeWidth={2.5} />
            </button>
          </div>
        </div>

        <div className="relative mb-5">
          <div className="absolute inset-y-0 left-3.5 flex items-center pointer-events-none text-gray-400 dark:text-gray-500">
            <Search size={18} strokeWidth={2.5} />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            placeholder="搜索提示词..."
            className="w-full bg-[#E3E3E8] dark:bg-[#1C1C1E] text-[17px] text-gray-900 dark:text-white rounded-[12px] pl-10 pr-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-[#007AFF]/40 placeholder-gray-500 dark:placeholder-gray-500 transition-shadow"
          />
        </div>

        <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4 md:mx-0 md:px-0">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveTab(cat)}
              className="relative px-5 py-2.5 rounded-full text-[15px] font-bold whitespace-nowrap transition-colors"
            >
              {activeTab === cat ? (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-[#007AFF] rounded-full shadow-md"
                  initial={false}
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                />
              ) : null}
              <span
                className={`relative z-10 ${
                  activeTab === cat
                    ? 'text-white'
                    : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'
                }`}
              >
                {cat}
              </span>
            </button>
          ))}
        </div>
      </header>

      <main className="px-4 py-6 md:px-8 mx-auto max-w-3xl">
        {filteredCards.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center mt-24 text-gray-400 dark:text-gray-500"
          >
            <div className="w-24 h-24 mb-5 rounded-full bg-gray-200/50 dark:bg-[#1C1C1E] flex items-center justify-center">
              <Search size={36} strokeWidth={1.5} />
            </div>
            <p className="text-[17px] font-medium">无相关卡片内容</p>
          </motion.div>
        ) : (
          <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <AnimatePresence mode="popLayout">
              {filteredCards.map((card) => (
                <Card
                  key={card.id}
                  card={card}
                  tagsById={tagsById}
                  onEdit={(data) => {
                    setEditingCard(data);
                    setIsSheetOpen(true);
                  }}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </main>

      <BottomSheet
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
        onSave={handleSaveCard}
        onDelete={handleDeleteCard}
        initialData={editingCard}
        tags={tags}
        onOpenTagManager={() => setIsTagManagerOpen(true)}
      />

      <TagManager
        isOpen={isTagManagerOpen}
        onClose={() => setIsTagManagerOpen(false)}
        categories={categoriesForTags}
        onChange={(nextTags) => {
          setTags(nextTags);
          const setIds = new Set(nextTags.map((t) => t.id));
          setCards((prev) => prev.map((c) => ({ ...c, tags: (c.tags || []).filter((id) => setIds.has(id)) })));
        }}
      />

      <style
        dangerouslySetInnerHTML={{
          __html: `
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        .pb-safe-area { padding-bottom: env(safe-area-inset-bottom, 24px); }
      `,
        }}
      />

      <div className="sr-only">Health check OK: {config.host}:{config.port}</div>
    </div>
  );
}
