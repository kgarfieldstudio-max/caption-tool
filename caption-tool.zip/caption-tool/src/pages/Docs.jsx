import React from 'react';
import SwaggerUI from 'swagger-ui-react';
import 'swagger-ui-react/swagger-ui.css';

const spec = {
  openapi: '3.0.3',
  info: {
    title: 'Caption Tool API',
    version: '1.0.0',
  },
  servers: [{ url: '/' }],
  paths: {
    '/health': {
      get: {
        summary: 'Health check',
        responses: {
          200: {
            description: 'Service is healthy',
          },
        },
      },
    },
  },
};

export default function Docs() {
  return <SwaggerUI spec={spec} />;
}
