export const APPLE_HIG_PALETTE = {
  primary: [
    { token: 'systemBlue', label: 'Blue', light: '#007AFFFF', dark: '#0A84FFFF' },
    { token: 'systemGreen', label: 'Green', light: '#33C659FF', dark: '#30D159FF' },
    { token: 'systemIndigo', label: 'Indigo', light: '#5956D6FF', dark: '#5E5BE5FF' },
    { token: 'systemOrange', label: 'Orange', light: '#FF9300FF', dark: '#FF9E0AFF' },
    { token: 'systemPink', label: 'Pink', light: '#FF2D54FF', dark: '#FF385EFF' },
    { token: 'systemPurple', label: 'Purple', light: '#AF51DDFF', dark: '#BF59F2FF' },
    { token: 'systemRed', label: 'Red', light: '#FF3A30FF', dark: '#FF443AFF' },
    { token: 'systemTeal', label: 'Teal', light: '#59C6F9FF', dark: '#63D1FFFF' },
    { token: 'systemYellow', label: 'Yellow', light: '#FFCC00FF', dark: '#FFD60AFF' },
    { token: 'systemMint', label: 'Mint', light: '#00C7BEFF', dark: '#63E6E2FF' },
    { token: 'systemCyan', label: 'Cyan', light: '#32ADE6FF', dark: '#64D2FFFF' }
  ],
  secondary: [
    { token: 'systemGray', label: 'Gray', light: '#8E8E93FF', dark: '#8E8E93FF' },
    { token: 'systemGray2', label: 'Gray 2', light: '#ADADB2FF', dark: '#636366FF' },
    { token: 'systemGray3', label: 'Gray 3', light: '#C6C6CCFF', dark: '#474749FF' },
    { token: 'systemGray4', label: 'Gray 4', light: '#D1D1D6FF', dark: '#3A3A3DFF' },
    { token: 'systemGray5', label: 'Gray 5', light: '#E5E5EAFF', dark: '#2B2B2DFF' },
    { token: 'systemGray6', label: 'Gray 6', light: '#F2F2F7FF', dark: '#1C1C1EFF' }
  ],
  semantic: [
    { token: 'label', label: 'Label', light: '#000000FF', dark: '#FFFFFFFF' },
    { token: 'secondaryLabel', label: 'Secondary Label', light: '#3D3D42FF', dark: '#EAEAF4FF' },
    { token: 'separator', label: 'Separator', light: '#3D3D42FF', dark: '#545459FF' },
    { token: 'link', label: 'Link', light: '#007AFFFF', dark: '#0A84FFFF' },
    { token: 'systemBackground', label: 'Background', light: '#FFFFFFFF', dark: '#000000FF' },
    { token: 'secondarySystemBackground', label: 'Secondary Background', light: '#F2F2F7FF', dark: '#1C1C1EFF' },
    { token: 'tertiarySystemBackground', label: 'Tertiary Background', light: '#FFFFFFFF', dark: '#2B2B2DFF' }
  ]
};

export const flattenApplePalette = () =>
  Object.values(APPLE_HIG_PALETTE)
    .flat()
    .reduce((acc, item) => {
      acc[item.token] = item;
      return acc;
    }, {});

