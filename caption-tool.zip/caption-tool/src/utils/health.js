import config from '../config.js';

export const getHealthUrl = () => `http://${config.host}:${config.port}/health`;
