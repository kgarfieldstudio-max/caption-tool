const env = {
  appEnv: (import.meta.env.VITE_APP_ENV || 'dev').toLowerCase(),
  host: import.meta.env.VITE_HOST || '127.0.0.1',
  port: Number(import.meta.env.VITE_PORT || 5173),
  logLevel: import.meta.env.VITE_LOG_LEVEL || 'info',
};

const config = {
  dev: {
    ...env,
  },
  test: {
    ...env,
  },
  prod: {
    ...env,
  },
};

export default config[env.appEnv] || config.dev;
