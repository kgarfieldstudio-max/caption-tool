import React from 'react';
import { createRoot } from 'react-dom/client';
import AppRouter from './routes/AppRouter.jsx';
import './styles/index.css';

createRoot(document.getElementById('root')).render(<AppRouter />);
