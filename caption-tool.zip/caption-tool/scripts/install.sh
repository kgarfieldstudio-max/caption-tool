#!/bin/sh
set -e

if [ ! -d node_modules ]; then
  echo "Installing npm dependencies..."
  npm install
else
  echo "node_modules already exists."
fi

echo "Done."
