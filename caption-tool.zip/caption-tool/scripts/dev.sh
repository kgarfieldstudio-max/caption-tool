#!/bin/sh
set -e

if [ ! -d node_modules ]; then
  echo "Please run scripts/install.sh first."
  exit 1
fi

export VITE_HOST=${VITE_HOST:-127.0.0.1}
export VITE_PORT=${VITE_PORT:-5173}
export VITE_LOG_LEVEL=${VITE_LOG_LEVEL:-info}

echo "Health check: http://${VITE_HOST}:${VITE_PORT}/health"
echo "Docs: http://${VITE_HOST}:${VITE_PORT}/docs"

npm run dev
