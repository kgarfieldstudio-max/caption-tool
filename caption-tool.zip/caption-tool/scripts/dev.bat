@echo off
setlocal

if not exist node_modules (
  echo Please run scripts\install.bat first.
  exit /b 1
)

set VITE_HOST=127.0.0.1
set VITE_PORT=5173
set VITE_LOG_LEVEL=info

echo Health check: http://%VITE_HOST%:%VITE_PORT%/health
echo Docs: http://%VITE_HOST%:%VITE_PORT%/docs

npm run dev
