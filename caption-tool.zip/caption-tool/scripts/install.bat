@echo off
setlocal

if not exist node_modules (
  echo Installing npm dependencies...
  npm install
) else (
  echo node_modules already exists.
)

echo Done.
